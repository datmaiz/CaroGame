import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class Server {
    private List<ObjectOutputStream> outputStreams = new ArrayList<>();
    private ServerSocket serverSocket;

    public Server() {
        try {
            serverSocket = new ServerSocket(1111);
            start();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void start() {
        while (true) {
            try {
                System.out.println("Waiting for connection...");
                Socket socket = serverSocket.accept();
                System.out.println("Client Connected: " + socket.getInetAddress().getHostAddress());

                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                outputStreams.add(outputStream);

                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                ClientHandler clientHandler = new ClientHandler(inputStream);
                clientHandler.start();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private class ClientHandler extends Thread {
        private ObjectInputStream inputStream;

        public ClientHandler(ObjectInputStream inputStream) {
            this.inputStream = inputStream;
        }

        @Override
        public void run() {
            try {
                while (true) {
                    PointStep data = (PointStep) inputStream.readObject();

                    System.out.println("Received update from client");

                    for (ObjectOutputStream outputStream : outputStreams) {
                        outputStream.writeObject(data);
                        outputStream.flush();
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        new Server();
    }
}